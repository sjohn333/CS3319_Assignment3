<!DOCTYPE=html>
<html>
<head>
	<title> Welcome </title>
	<link rel="stylesheet" href="MakePretty.css">
</head>

<body>

<h1> Welcome!</h1>
<h2> Select which area you would like to enter: </h2>
<!--Enter the doctor area vai button-->
<form action="doctorOpeningPage.php" method="post">
	<input type="submit" value="Doctors"><br>
</form>
<!--Enter the Hospital Area via button -->
<form action="hospitalOpeningPage.php" method="post">
	<input type="submit" value="Hospitals"><br>
</form>
<!--Enter the patient area via button -->
<form action="patientOpeningPage.php" method="post">
	<input type="submit" value="Patients"><br>
</form>

</body>
</html>
