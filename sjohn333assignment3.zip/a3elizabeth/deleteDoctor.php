<!DOCTYPE=html>
<html>
<head>
	<title> Doctors Office </title>
	<link rel="stylesheet" href="MakePretty.css">
</head>
<h1> Delete a doctor! </h1>
<body>
<!--Area where you input the license number of the doctor you want to delete-->
<form action="checkDelete.php" method="post">
<h2> What is the License Number of the Doctor you wish to delete?</h2>
	<input type="text" name="LicNum"><br>
	<input type="submit" value="submit"/>
</form>
</body>
</html>
